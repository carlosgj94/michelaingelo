RT-01 revision 5 foam prototype

Open README.md and the revision 5 response in docs/rotary-table-design-audit-2026-11-18.md.
25 oriented assembly STLs, a fit coupon and one drain catch STL to print four times. Use the metal STEP files with the machining specification and supplier drawings.
The native assembly, generators and verification evidence are included. The repository holds the original arm source and historical native files.
The current bill of materials and SO100 arm reference are in the repository.
https://github.com/carlosgj94/michelaingelo/blob/main/docs/rotary-table-bom.md
https://github.com/carlosgj94/michelaingelo/blob/main/references/so-arm100/README.md
Physical fit, load, thermal, ingress and stopping acceptance remain pending.
