RT-01 revision 5 foam prototype

Open README.md and the revision 5 response in docs/rotary-table-design-audit-2026-11-18.md.
The CAD and package follow-up in that audit records the revised F19 service and P54 capacities.
25 oriented assembly STLs, a fit coupon, and one drain catch STL to print four times.
The arm-seat and foam-fixture folders contain the prototype prints and their manifests.
Use the metal STEP files with the machining specification and supplier drawings.
The native assembly, generators and verification evidence are included.
The repository holds the current bill of materials, SO100 arm reference and historical native files.
https://github.com/carlosgj94/michelaingelo/blob/main/docs/rotary-table-bom.md
https://github.com/carlosgj94/michelaingelo/blob/main/references/so-arm100/README.md
Physical fit, load, thermal, ingress and stopping acceptance remain pending.
