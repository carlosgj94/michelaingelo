RT-01 revision 4 prototype

Open README.md and docs/rotary-table-audit-response-2026-11-17.md first.
25 oriented assembly STLs plus a fit coupon. Metal STEP files require the machining specification and supplier/fabricator review.
Native SolidCraft model, generators, current checks and review evidence are included. Historical native files and the original arm source are in the repository, not duplicated in this package.
No slicing, physical printing, load/accuracy or ingress qualification is claimed. See remaining release gates before ordering or operation.
