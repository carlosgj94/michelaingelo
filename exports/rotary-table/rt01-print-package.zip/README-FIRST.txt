RT-01 revision 5 foam prototype

Open README.md and the revision 5 response in docs/rotary-table-design-audit-2026-11-18.md.
25 oriented assembly STLs plus a fit coupon. Use the metal STEP files with the machining specification and supplier drawings.
The native assembly, generators, BOM and verification evidence are included. The repository holds the original arm source and historical native files.
Physical fit, load, thermal, ingress and stopping acceptance remain pending.
