RT-01 revision 3 prototype package — 2026-11-17

Read docs/rotary-table-printing.md and docs/rotary-table-fasteners.md first.
33 assembly STLs plus one fit coupon are oriented for the A1 Mini. All units mm.
Print-fit, load, stiffness, thermal and ingress tests have not been performed.
The arm stand uses fabricated steel parts; do not print the metal STEP files.
M55 is one backing-strip drawing: MAKE TWO and fit below the chosen bench.
Known hardware: 106 defined-length screws and 18 bench bolts; final bench lengths
and unselected-device interfaces remain pending in the fastener register.
The native assembly and complete assembly STEP are separate repository files.
